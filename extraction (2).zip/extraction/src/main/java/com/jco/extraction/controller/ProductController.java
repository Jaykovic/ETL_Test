package com.jco.extraction.controller;

import com.jco.extraction.model.Product;
import com.jco.extraction.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@RestController
public class ProductController {

    //
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private KafkaTemplate<Object, Object> kafkaTemplate;

    @GetMapping("/")
    public String postData() {

      //  List<Product> fileData = productRepository.findAll();
        Collection<Product> prdlist = productRepository.findAll();
        for(Product product : prdlist){
            System.out.println(product.toString());
            kafkaTemplate.send("source_topic", product.toString());
        }
//        System.out.println(Arrays.toString(fileData.toArray()));
//       kafkaTemplate.send("source_topic",Arrays.toString(fileData.toArray()));

//        for (Product individualRecord : fileData) {
//
//            System.out.println(individualRecord);
//            kafkaTemplate.send("source_topic", individualRecord);
//
//        }

        return "records sent to kafka";
    }
}
