package com.jco.extraction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtractionDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtractionDemoApplication.class, args);
	}

}
