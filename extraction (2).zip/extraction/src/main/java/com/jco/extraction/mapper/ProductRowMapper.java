package com.jco.extraction.mapper;

import com.jco.extraction.model.Product;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductRowMapper implements RowMapper<Product> {

    public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
        Product product = new Product();
        //product.setId(rs.getInt("id"));
        product.setProduct_name(rs.getString("product_name"));
        product.setPrice(rs.getFloat("price"));

//        String msg = null;
//        while (rs.next()) {
////            int id = rs.getInt("id");
////            String productName = rs.getString("product_name");
////            float price = rs.getFloat("price");
////            msg = id + "," + productName + "," + price;
//          //  result.add(product);
//        }

        return product;
    }
}