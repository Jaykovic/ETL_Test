package com.jco.extraction.repository;

import com.jco.extraction.mapper.ProductRowMapper;
import com.jco.extraction.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

@Repository
public class ProductRepository
{
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Transactional(readOnly = true)
    public Collection<Product> findAll(){
        List<Product> productList = jdbcTemplate.query("select * from Products", new ProductRowMapper());
        return productList;
    }

}