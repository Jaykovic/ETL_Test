package com.jco.loading.repository;

import com.jco.loading.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDataRepository extends JpaRepository<Product, String> {
}
