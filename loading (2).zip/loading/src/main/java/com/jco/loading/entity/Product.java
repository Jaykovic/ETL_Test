package com.jco.loading.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "demo")
@Getter
@Setter
public class Product {

    public Product() {
    }

    public Product(int id, String product_name, String price) {
        this.id = id;
        this.product_name = product_name;
        this.price = price;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private int id;

    @Column
    private String product_name;

    @Column
    private String price;

}
