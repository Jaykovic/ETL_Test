package com.jco.loading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoadingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoadingDemoApplication.class, args);
	}

}
