package com.jco.loading.controller;

import com.jco.loading.entity.Product;
import com.jco.loading.repository.ProductDataRepository;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumer.class);

    @Autowired
    private ProductDataRepository productDataRepository;

    public KafkaConsumer(ProductDataRepository productDataRepository) {
        this.productDataRepository = productDataRepository;
    }

    @KafkaListener(topics = "source_topic", groupId = "myAppGroup")
    public void consume(String data){

        String[] gettingEveryCharAsString = data.split(",");
        Product product = new Product(0, gettingEveryCharAsString[0], gettingEveryCharAsString[1]);

       // product.setPrice(price);
//        product.setId(Id);

        productDataRepository.save(product);
    }

//    @KafkaListener(topics = "source_topic", groupId = "myAppGroup")
//    public void consume(ConsumerRecord<String, String > consumerRecord){
//        String recomd =  consumerRecord.value().toString();
//        String recc = (recomd.substring(0, recomd.length()-1)).substring(1);
//        String[] recomdArray = recc.split(",");
//
//        Integer Id = Integer.parseInt(recomdArray[0]);
//
//
//        String product_name = String.valueOf(recomdArray[1]);
//        float price = Float.parseFloat(recomdArray[2]);
//
//        LOGGER.info(String.format("Message received -> %s", product_name, price));
//        String finalDta = product_name + "," + price;
//
////        Product product = new Product();
////        product.setProduct_name(name);
////        product.setPrice(price);
//        System.out.println(finalDta);
//        productDataRepository.save(finalDta);
//    }
}

